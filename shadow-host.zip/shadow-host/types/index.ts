export type ProjectStatus = 'Ready' | 'Building' | 'Failed';
export type Project = { id: string; name: string; framework: string; domain: string; status: ProjectStatus; updated: string; branch: string };
