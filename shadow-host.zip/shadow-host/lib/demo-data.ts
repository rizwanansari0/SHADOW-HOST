import type { Project } from '@/types';
export const demoProjects: Project[] = [
  { id: 'prj_8x2k', name: 'aurora-storefront', framework: 'Next.js', domain: 'aurora-storefront.shadow-demo.app', status: 'Ready', updated: '4 min ago', branch: 'main' },
  { id: 'prj_3m9q', name: 'docs-portal', framework: 'Astro', domain: 'docs-portal.shadow-demo.app', status: 'Building', updated: '18 min ago', branch: 'main' },
  { id: 'prj_1v7p', name: 'portfolio-2026', framework: 'Vite', domain: 'portfolio-2026.shadow-demo.app', status: 'Ready', updated: '2 hours ago', branch: 'production' }
];
export const demoTraffic = [
  { day: 'Mon', visitors: 820, requests: 2200 }, { day: 'Tue', visitors: 1160, requests: 3100 }, { day: 'Wed', visitors: 940, requests: 2750 }, { day: 'Thu', visitors: 1520, requests: 4100 }, { day: 'Fri', visitors: 1320, requests: 3600 }, { day: 'Sat', visitors: 1840, requests: 4900 }, { day: 'Sun', visitors: 1660, requests: 4500 }
];
