import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Settings'};
export default function Page(){return <DashboardPage page="settings"/>}
