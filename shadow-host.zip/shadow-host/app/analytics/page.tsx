import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Analytics'};
export default function Page(){return <DashboardPage page="analytics"/>}
