import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Billing'};
export default function Page(){return <DashboardPage page="billing"/>}
