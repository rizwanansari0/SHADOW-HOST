import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Dashboard'};
export default function Page(){return <DashboardPage page="dashboard"/>}
