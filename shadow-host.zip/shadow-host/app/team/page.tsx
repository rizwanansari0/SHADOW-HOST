import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Team'};
export default function Page(){return <DashboardPage page="team"/>}
