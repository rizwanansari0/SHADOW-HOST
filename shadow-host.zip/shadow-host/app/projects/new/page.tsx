import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'New Project'};
export default function Page(){return <DashboardPage page="new-project"/>}
