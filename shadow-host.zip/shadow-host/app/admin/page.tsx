import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Admin'};
export default function Page(){return <DashboardPage page="admin"/>}
