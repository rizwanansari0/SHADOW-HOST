import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Domains'};
export default function Page(){return <DashboardPage page="domains"/>}
