import { DashboardPage } from '@/components/dashboard-pages';
export const metadata={title:'Deployments'};
export default function Page(){return <DashboardPage page="deployments"/>}
