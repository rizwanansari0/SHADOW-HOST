import type { Metadata } from 'next'; import './globals.css';
export const metadata: Metadata = { title: {default:'SHADOW HOST — Deploy fast. Scale without limits.',template:'%s · SHADOW HOST'}, description:'A modern hosting platform concept with project management, deployment workflows, analytics, and a polished developer dashboard.', applicationName:'SHADOW HOST', robots:{index:true,follow:true} };
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
