'use client';
import { useState } from 'react';
import Link from 'next/link';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { Logo } from './logo';
export function SiteHeader() {
 const [open,setOpen]=useState(false); const links=[['Features','#features'],['Pricing','/pricing'],['Documentation','/docs'],['Support','/support']];
 return <header className="site-header"><div className="container nav-inner"><Logo/><nav className={open?'nav-links nav-open':'nav-links'}>{links.map(([label,href])=><Link key={label} href={href} onClick={()=>setOpen(false)}>{label}</Link>)}<div className="mobile-actions"><Link className="btn btn-ghost" href="/login">Log in</Link><Link className="btn btn-primary" href="/signup">Get started <ArrowUpRight size={16}/></Link></div></nav><div className="nav-actions"><Link href="/login" className="login-link">Log in</Link><Link href="/signup" className="btn btn-primary nav-cta">Get started <ArrowUpRight size={16}/></Link></div><button className="menu-toggle" aria-label="Toggle navigation" onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button></div></header>
}
