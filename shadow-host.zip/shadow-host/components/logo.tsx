import { Shield } from 'lucide-react';
export function Logo({ small = false }: { small?: boolean }) { return <a href="/" className="brand"><span className="brand-mark"><Shield size={small ? 17 : 20} strokeWidth={2.4}/></span><span>SHADOW<span className="brand-light"> HOST</span></span></a>; }
